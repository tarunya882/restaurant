import React from "react";
import { OutlinedInput } from "@material-ui/core";

const SearchBar = (props) => {
    return <OutlinedInput {...props} />;
};

export default SearchBar;
